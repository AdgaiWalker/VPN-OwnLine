# 长青 · 中文 Web 交互原型

当前为普通响应式 Web 页面：无手机外框、设备切换、模拟键盘或状态栏。保留四项设置任务，每次只展开一项；连接时同时填写公网 IP、用户名和密码，私钥与高级选项按需打开。

这是工作区内的独立前端演示，配合产品交互规格 v1.6；不是产品仓库或线上服务。所有连接、安装、云发现和客户端导入均为模拟。产品详细需求以工作区 `仓库/docs/设计/客户端Web交互设计规格说明书.md` 为准，不在此复制完整规格。

## 本地体验

本机服务运行时打开 [Web 原型](http://127.0.0.1:4173/)。重新启动时：

```sh
npm ci
npm run dev -- --host 127.0.0.1 --port 4173 --strictPort
```

默认场景为“已有服务器，准备连接”。“原型演示”可切换未购服务器、连接失败或客户端导入场景。示例使用文档 IP 和 `.example` 域名，请勿输入真实凭据。

- 点击“连接”后查看模拟检查结果，再主动选择“开始安装”。刷新可恢复不含敏感信息的演示进度。
- “进入管理页”在原型中转到导入演示，不打开真实交付地址。
- 客户端按浏览器平台展示：iOS 为 Shadowrocket；Mac 为 Shadowrocket、Clash；Android 为 FL Clash、Clash；Windows/Linux 为 Clash、FL Clash。此处平台判断不证明真实应用已安装。
- “完成”为当前浏览器会话内的可选自报，不检测设备连接；“复制链接”可独立使用。
- “查找服务器信息”提供九家厂商官网导航与文字步骤；厂商字段截图和登录后的移动控制台未实测。腾讯云列表仅是示例，不访问账号或索取 API 密钥。
- “复制命令”复制真实仓库的部署命令，但不会执行；另行运行会修改服务器。

## 文件导航

| 用途 | 位置 |
|---|---|
| 当前开发约束 | [AGENTS.md](AGENTS.md) |
| 应用入口 | [src/App.tsx](src/App.tsx) |
| 页面与任务交互 | [src/Prototype.tsx](src/Prototype.tsx) |
| Web 样式与弹窗 | [src/prototype.css](src/prototype.css)、[src/WebDialog.tsx](src/WebDialog.tsx) |
| 当前验收范围及证据 | [design-qa.md](design-qa.md) |
| 当前 Web 截图 | [browser-web-setup.png](artifacts/browser-web-setup.png) |
| 选中视觉源，仅作来源追溯 | [source-selected.png](artifacts/source-selected.png) |
| 早期手机截图 | [artifacts/archive/mobile/](artifacts/archive/mobile/) |
| 历史说明及验收 | [docs/归档/](docs/归档/) |

原模板的 `src/mobile/` 与资源仍保留但不挂载，不是第二个可用产品。`node_modules/` 为依赖、`dist/` 为生成产物，不作为现行文档或修改入口。

## 验证与边界

```sh
npm run check:runtime
npm run build
```

原型密码、私钥和示例管理密码仅保留在内存中；浏览器仅保存非敏感演示状态。真实 SSH、云授权、后台持续任务、原生客户端唤起、下载兜底、订阅与公网可用性均待产品实现和实机验证。产品规格的 62 项验收仍待执行；当前前端检查不替代生产结果。

未推送、发布或部署此原型。
